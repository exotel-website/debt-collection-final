
export interface CalculatorData {
  collectionAgents: number;
  totalAccountsPerAgent: number;
  currentResolutionRate: number;
  averageDebtPerAccount: number;
  collectionCycleDays: number;
  currency: string;
}

export interface SliderData {
  improvedResolutionRate: number;
  resourceOptimization: number;
}

export interface CalculatedResults {
  current: {
    yearlyResolutions: number;
    yearlyCollection: number;
  };
  improvement: {
    appliedResolutionImprovement: number;
    appliedResourceOptimization: number;
    combinedImprovementFactor: number;
    earlyResolutions: number;
    financialEquivalent: number;
    agentSavings: number;
  };
  final: {
    newAgentCount: number;
    increasedCapability: number;
    newResolutionRate: number;
    earlyResolutions: number;
    financialEquivalent: number;
    agentSavings: number;
    totalYearlyResolutions: number;
    totalYearlyCollection: number;
    totalAnnualSavings: number;
    roi: number;
    savingsYearlyResolutions: number;
    savingsYearlyCollection: number;
  };
}
