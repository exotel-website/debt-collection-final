
import { useState } from 'react';
import { CalculatorData, SliderData, CalculatedResults } from '@/types/calculator';
import { generateEnhancedPDFReport } from '@/utils/enhancedPdfReportGenerator';

interface EmailCaptureData {
  email: string;
  name: string;
  agreeToPrivacy: boolean;
}

const ZAPIER_WEBHOOK_URL = 'https://hooks.zapier.com/hooks/catch/555541/u34eoy5/';

export const usePdfReport = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [hasDownloaded, setHasDownloaded] = useState(false);

  const openModal = () => {
    // Check if user has already provided email
    const savedEmail = localStorage.getItem('exotel_user_email');
    if (savedEmail) {
      // Skip modal if email already captured
      return true; // Indicates can proceed directly
    }
    setIsModalOpen(true);
    return false; // Indicates need to show modal
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  const sendToZapier = async (data: any) => {
    try {
      await fetch(ZAPIER_WEBHOOK_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        mode: 'no-cors',
        body: JSON.stringify({
          timestamp: new Date().toISOString(),
          triggered_from: window.location.origin,
          report_data: data,
        }),
      });
      console.log('Report data sent to Zapier webhook successfully');
    } catch (error) {
      console.error('Error sending data to Zapier webhook:', error);
    }
  };

  const generateReport = async (
    inputData: CalculatorData,
    sliderData: SliderData,
    results: CalculatedResults,
    userInfo?: EmailCaptureData
  ) => {
    setIsGenerating(true);
    
    try {
      let emailData: EmailCaptureData;
      
      if (userInfo) {
        // Save email to localStorage for future use
        localStorage.setItem('exotel_user_email', userInfo.email);
        localStorage.setItem('exotel_user_name', userInfo.name);
        emailData = userInfo;
      } else {
        // Get saved data from localStorage
        const savedEmail = localStorage.getItem('exotel_user_email');
        const savedName = localStorage.getItem('exotel_user_name');
        
        if (!savedEmail || !savedName) {
          throw new Error('No email or name found');
        }
        
        emailData = {
          email: savedEmail,
          name: savedName,
          agreeToPrivacy: true,
        };
      }

      // Prepare data for Zapier webhook
      const webhookData = {
        user_info: {
          email: emailData.email,
          name: emailData.name,
        },
        input_data: inputData,
        slider_data: sliderData,
        calculated_results: results,
        report_generated_at: new Date().toISOString(),
      };

      // Send data to Zapier webhook
      await sendToZapier(webhookData);

      await generateEnhancedPDFReport({
        inputData,
        sliderData,
        results,
        userInfo: {
          email: emailData.email,
          companyName: emailData.name,
        },
      });

      setHasDownloaded(true);
      setIsModalOpen(false);
      
      // Analytics tracking could be added here
      console.log('PDF report generated successfully');
      
    } catch (error) {
      console.error('Error generating PDF report:', error);
      // Could add toast notification here
    } finally {
      setIsGenerating(false);
    }
  };

  return {
    isModalOpen,
    isGenerating,
    hasDownloaded,
    openModal,
    closeModal,
    generateReport,
  };
};
