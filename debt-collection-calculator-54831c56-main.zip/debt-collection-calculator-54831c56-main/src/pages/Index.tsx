import DebtCollectionCalculator from "@/components/DebtCollectionCalculator";
import HeroSection from "@/components/landing/HeroSection";
import FeaturesSection from "@/components/landing/FeaturesSection";
import CTASection from "@/components/landing/CTASection";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <HeroSection />

      {/* Calculator Section */}
      <div id="calculator-section" className="scroll-mt-4">
        <DebtCollectionCalculator />
      </div>

      {/* Features Section */}
      <FeaturesSection />

      {/* CTA Section */}
      <CTASection />
    </div>
  );
};

export default Index;
