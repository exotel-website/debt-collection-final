import jsPDF from 'jspdf';
import { CalculatorData, SliderData, CalculatedResults } from '@/types/calculator';

interface ReportData {
  inputData: CalculatorData;
  sliderData: SliderData;
  results: CalculatedResults;
  userInfo: {
    email: string;
    companyName?: string;
  };
}

// Colors constants for enhanced design
const COLORS = {
  exotelTeal: '#00B4A6',
  exotelTealLight: '#33C4B7',
  exotelTealDark: '#008A7D',
  darkGray: '#374151',
  mediumGray: '#6B7280',
  lightGray: '#9CA3AF',
  extraLightGray: '#F3F4F6',
  white: '#FFFFFF',
  accent: '#F59E0B',
  success: '#10B981',
  warning: '#F59E0B',
} as const;

// Helper function to check if new page is needed
const checkPageBreak = (pdf: jsPDF, yPos: number, requiredSpace: number = 40): { yPos: number; addedPage: boolean } => {
  const pageHeight = pdf.internal.pageSize.getHeight();
  if (yPos > pageHeight - requiredSpace) {
    pdf.addPage();
    return { yPos: 15, addedPage: true };
  }
  return { yPos, addedPage: false };
};

// Create PDF header with logo and title
const createHeader = async (pdf: jsPDF): Promise<number> => {
  const pageWidth = pdf.internal.pageSize.getWidth();
  
  // Header background
  pdf.setFillColor(0, 180, 166);
  pdf.rect(0, 0, pageWidth, 25, 'F');
  
  // Add Exotel logo
  try {
    const logoImg = new Image();
    logoImg.src = '/lovable-uploads/0217996f-63c5-4733-80d8-f3ab87a906b4.png';
    await new Promise((resolve) => {
      logoImg.onload = resolve;
      logoImg.onerror = resolve; // Fallback to text if logo fails
    });
    
    if (logoImg.complete && logoImg.naturalWidth > 0) {
      // Calculate logo dimensions to fit nicely in header
      const logoHeight = 12;
      const logoWidth = (logoImg.naturalWidth / logoImg.naturalHeight) * logoHeight;
      pdf.addImage(logoImg, 'PNG', 20, 6.5, logoWidth, logoHeight);
    } else {
      // Fallback to text
      pdf.setTextColor(255, 255, 255);
      pdf.setFontSize(20);
      pdf.setFont('helvetica', 'bold');
      pdf.text('EXOTEL', 20, 16);
    }
  } catch (error) {
    // Fallback to text if logo loading fails
    pdf.setTextColor(255, 255, 255);
    pdf.setFontSize(20);
    pdf.setFont('helvetica', 'bold');
    pdf.text('EXOTEL', 20, 16);
  }
  
  // Header title
  pdf.setTextColor(255, 255, 255);
  pdf.setFontSize(14);
  pdf.setFont('helvetica', 'normal');
  pdf.text('Debt Collection ROI Analysis Report', pageWidth - 20, 16, { align: 'right' });
  
  return 25;
};

// Add company and user information
const addCompanyInfo = (pdf: jsPDF, userInfo: ReportData['userInfo'], yPos: number): number => {
  const pageWidth = pdf.internal.pageSize.getWidth();
  
  yPos += 10;
  pdf.setTextColor(COLORS.darkGray);
  pdf.setFontSize(12);
  pdf.setFont('helvetica', 'normal');
  pdf.text(`Generated for: ${userInfo.email}`, 20, yPos);
  pdf.text(`Date: ${new Date().toLocaleDateString()}`, pageWidth - 20, yPos, { align: 'right' });
  
  return yPos + 10;
};

// Create results comparison table
const createResultsTable = (pdf: jsPDF, inputData: CalculatorData, results: CalculatedResults, yPos: number): number => {
  // Section title
  pdf.setFontSize(16);
  pdf.setFont('helvetica', 'bold');
  pdf.setTextColor(COLORS.exotelTeal);
  pdf.text('Results Comparison', 20, yPos);
  yPos += 10;
  
  // Table data
  const tableData = [
    ['Metric', 'Current', 'With Exotel', 'Improvement'],
    [
      'Yearly Resolutions',
      results.current.yearlyResolutions.toLocaleString(),
      results.final.totalYearlyResolutions.toLocaleString(),
      `+${(results.final.totalYearlyResolutions - results.current.yearlyResolutions).toLocaleString()}`
    ],
    [
      'Yearly Collection',
      `${inputData.currency} ${results.current.yearlyCollection.toLocaleString()}`,
      `${inputData.currency} ${results.final.totalYearlyCollection.toLocaleString()}`,
      `+${inputData.currency} ${(results.final.totalYearlyCollection - results.current.yearlyCollection).toLocaleString()}`
    ],
    [
      'Agent Count',
      inputData.collectionAgents.toString(),
      results.final.newAgentCount.toString(),
      `-${results.final.agentSavings} agents`
    ]
  ];
  
  // Draw table
  const colWidths = [60, 40, 40, 40];
  const startX = 20;
  let currentY = yPos;
  
  tableData.forEach((row, rowIndex) => {
    let currentX = startX;
    
    row.forEach((cell, colIndex) => {
      if (rowIndex === 0) {
        pdf.setFont('helvetica', 'bold');
        pdf.setFillColor(240, 240, 240);
        pdf.rect(currentX, currentY - 4, colWidths[colIndex], 8, 'F');
      } else {
        pdf.setFont('helvetica', 'normal');
      }
      
      pdf.setFontSize(9);
      pdf.setTextColor(COLORS.darkGray);
      pdf.text(cell, currentX + 2, currentY);
      currentX += colWidths[colIndex];
    });
    
    currentY += 8;
  });
  
  return currentY + 15;
};

// Create key benefits section
const createKeyBenefits = (pdf: jsPDF, inputData: CalculatorData, results: CalculatedResults, yPos: number): number => {
  pdf.setFontSize(16);
  pdf.setFont('helvetica', 'bold');
  pdf.setTextColor(COLORS.exotelTeal);
  pdf.text('Key Benefits', 20, yPos);
  yPos += 10;
  
  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'normal');
  pdf.setTextColor(COLORS.darkGray);
  
  const benefits = [
    `${results.final.agentSavings} fewer agents needed`,
    `${((results.final.newResolutionRate - inputData.currentResolutionRate) / inputData.currentResolutionRate * 100).toFixed(1)}% improvement in resolution rate`,
    `${inputData.currency} ${results.final.financialEquivalent.toLocaleString()} additional yearly collection`,
    `${results.final.roi}% ROI on investment`
  ];
  
  benefits.forEach((benefit) => {
    pdf.text('• ' + benefit, 25, yPos);
    yPos += 6;
  });
  
  return yPos + 10;
};

// Create solution pillar with number circle
const createSolutionPillar = (pdf: jsPDF, pillar: any, yPos: number): number => {
  // Draw number circle
  pdf.setFillColor(0, 180, 166);
  pdf.circle(30, yPos + 3, 8, 'F');
  pdf.setTextColor(255, 255, 255);
  pdf.setFontSize(14);
  pdf.setFont('helvetica', 'bold');
  pdf.text(pillar.number, 30, yPos + 7, { align: 'center' });
  
  // Title
  pdf.setTextColor(COLORS.exotelTeal);
  pdf.setFontSize(12);
  pdf.setFont('helvetica', 'bold');
  pdf.text(pillar.title, 45, yPos + 5);
  yPos += 12;
  
  // Description
  pdf.setTextColor(COLORS.darkGray);
  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'normal');
  const descLines = pdf.splitTextToSize(pillar.description, 140);
  pdf.text(descLines, 45, yPos);
  yPos += descLines.length * 4 + 5;
  
  // Features
  pillar.features.forEach((feature: string) => {
    pdf.setFontSize(9);
    pdf.text(feature, 50, yPos);
    yPos += 5;
  });
  
  return yPos + 8;
};

// Create Exotel strategy section
const createExotelStrategy = (pdf: jsPDF, inputData: CalculatorData, results: CalculatedResults, yPos: number): number => {
  const pageBreak = checkPageBreak(pdf, yPos, 60);
  yPos = pageBreak.yPos;
  
  pdf.setFontSize(18);
  pdf.setFont('helvetica', 'bold');
  pdf.setTextColor(COLORS.exotelTeal);
  pdf.text('Revamp Your Debt Collection Strategy', 20, yPos);
  yPos += 8;
  
  pdf.setFontSize(14);
  pdf.setFont('helvetica', 'normal');
  pdf.setTextColor(COLORS.darkGray);
  pdf.text('Transition from reactive to proactive', 20, yPos);
  yPos += 5;
  
  // Add personalized summary
  pdf.setFontSize(10);
  pdf.setTextColor(COLORS.lightGray);
  const summary = `Based on your ${inputData.collectionAgents} agents managing ${inputData.totalAccountsPerAgent} accounts each with ${inputData.currentResolutionRate}% resolution rate, here's how Exotel can help you achieve ${results.final.agentSavings} fewer agents and ${inputData.currency} ${results.final.financialEquivalent.toLocaleString()} additional collection:`;
  const summaryLines = pdf.splitTextToSize(summary, 170);
  pdf.text(summaryLines, 20, yPos);
  yPos += summaryLines.length * 4 + 10;
  
  // Solution pillars data
  const solutionPillars = [
    {
      number: '1',
      title: 'Automate with AI-Powered Conversations',
      description: 'Leverage advanced voicebots and chatbots for 24/7 personalized borrower engagement with seamless agent fallback.',
      features: [
        '• AI-powered interactions that mimic human conversation',
        '• Seamless fallback to live agents and other channels', 
        '• Multilingual capabilities: English, Hindi, Hinglish, Arabic and more'
      ]
    },
    {
      number: '2', 
      title: 'Personalized & Digital-First Engagements',
      description: 'Reach borrowers where they prefer and create connected engagement experiences.',
      features: [
        '• Proactive outreach with targeted campaigns',
        '• Multi-channel orchestration for engagement journeys',
        '• AI personalization for improved outcomes'
      ]
    },
    {
      number: '3',
      title: 'Omni-channel Contact Center', 
      description: 'All-in-one contact center designed for seamless and efficient debt recovery.',
      features: [
        '• Unified agent desktop',
        '• AI-powered quality analysis & agent assistance',
        '• Fast plug&play integrations with popular CRMs'
      ]
    },
    {
      number: '4',
      title: 'Streamline Collections with Unified APIs',
      description: 'Boost field collection efforts with unified communication APIs and real-time data.',
      features: [
        '• Access all communication APIs & SDKs on single platform',
        '• Easy integration with field agent mobile apps',
        '• Unified view of customer interactions across channels'
      ]
    }
  ];
  
  // Create each pillar
  solutionPillars.forEach((pillar) => {
    const pageBreak = checkPageBreak(pdf, yPos, 50);
    yPos = pageBreak.yPos;
    yPos = createSolutionPillar(pdf, pillar, yPos);
  });
  
  return yPos + 5;
};

// Create footer section
const createFooter = (pdf: jsPDF): void => {
  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();
  
  // Footer background
  pdf.setFillColor(0, 180, 166);
  pdf.rect(0, pageHeight - 30, pageWidth, 30, 'F');
  
  // Footer text
  pdf.setTextColor(255, 255, 255);
  pdf.setFontSize(12);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Ready to get started?', 20, pageHeight - 20);
  
  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'normal');
  pdf.text('Contact us at sales@exotel.com or visit exotel.com', 20, pageHeight - 12);
  pdf.text('Book a Demo Today!', pageWidth - 20, pageHeight - 12, { align: 'right' });
};

// Main PDF generation function
export const generatePDFReport = async (data: ReportData): Promise<void> => {
  const { inputData, sliderData, results, userInfo } = data;
  
  // Create new PDF document
  const pdf = new jsPDF('p', 'mm', 'a4');
  
  // Generate PDF sections
  let yPos = await createHeader(pdf);
  yPos = addCompanyInfo(pdf, userInfo, yPos);
  yPos = createResultsTable(pdf, inputData, results, yPos);
  yPos = createKeyBenefits(pdf, inputData, results, yPos);
  yPos = createExotelStrategy(pdf, inputData, results, yPos);
  
  // Add footer
  createFooter(pdf);
  
  // Save the PDF
  const fileName = 'Exotel_ROI_Report.pdf';
  pdf.save(fileName);
};