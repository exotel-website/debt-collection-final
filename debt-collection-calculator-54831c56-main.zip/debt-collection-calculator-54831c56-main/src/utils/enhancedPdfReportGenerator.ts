import jsPDF from 'jspdf';
import { CalculatorData, SliderData, CalculatedResults } from '@/types/calculator';

interface ReportData {
  inputData: CalculatorData;
  sliderData: SliderData;
  results: CalculatedResults;
  userInfo: {
    email: string;
    companyName?: string;
  };
}

// Enhanced color palette for professional design
const COLORS = {
  primary: [0, 180, 166] as [number, number, number],           // Exotel Teal
  primaryLight: [51, 196, 183] as [number, number, number],     // Light Teal
  primaryDark: [0, 138, 125] as [number, number, number],       // Dark Teal
  secondary: [245, 158, 11] as [number, number, number],        // Accent Orange
  success: [16, 185, 129] as [number, number, number],          // Success Green
  dark: [55, 65, 81] as [number, number, number],               // Dark Gray
  medium: [107, 114, 128] as [number, number, number],          // Medium Gray
  light: [156, 163, 175] as [number, number, number],           // Light Gray
  extraLight: [243, 244, 246] as [number, number, number],      // Extra Light Gray
  white: [255, 255, 255] as [number, number, number],           // White
  warning: [239, 68, 68] as [number, number, number],           // Warning Red
};

// Utility functions
const hexToRgb = (hex: string): [number, number, number] => {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? [
    parseInt(result[1], 16),
    parseInt(result[2], 16),
    parseInt(result[3], 16)
  ] : [0, 0, 0];
};

const setColor = (pdf: jsPDF, color: [number, number, number], type: 'fill' | 'text' = 'text') => {
  if (type === 'fill') {
    pdf.setFillColor(color[0], color[1], color[2]);
  } else {
    pdf.setTextColor(color[0], color[1], color[2]);
  }
};

const checkPageBreak = (pdf: jsPDF, yPos: number, requiredSpace: number = 40): { yPos: number; addedPage: boolean } => {
  const pageHeight = pdf.internal.pageSize.getHeight();
  if (yPos > pageHeight - requiredSpace) {
    pdf.addPage();
    return { yPos: 20, addedPage: true };
  }
  return { yPos, addedPage: false };
};

// Enhanced header with gradient effect
const createEnhancedHeader = async (pdf: jsPDF): Promise<number> => {
  const pageWidth = pdf.internal.pageSize.getWidth();
  
  // Gradient header background (simulated with multiple rectangles)
  for (let i = 0; i < 25; i++) {
    const alpha = 1 - (i / 25) * 0.3;
    const color = COLORS.primary.map(c => Math.round(c * alpha + 255 * (1 - alpha))) as [number, number, number];
    setColor(pdf, color, 'fill');
    pdf.rect(0, i, pageWidth, 1, 'F');
  }
  
  // Add Exotel logo
  try {
    const logoImg = new Image();
    logoImg.src = '/lovable-uploads/0217996f-63c5-4733-80d8-f3ab87a906b4.png';
    await new Promise((resolve) => {
      logoImg.onload = resolve;
      logoImg.onerror = resolve;
    });
    
    if (logoImg.complete && logoImg.naturalWidth > 0) {
      const logoHeight = 15;
      const logoWidth = (logoImg.naturalWidth / logoImg.naturalHeight) * logoHeight;
      pdf.addImage(logoImg, 'PNG', 20, 5, logoWidth, logoHeight);
    } else {
      setColor(pdf, COLORS.white);
      pdf.setFontSize(22);
      pdf.setFont('helvetica', 'bold');
      pdf.text('EXOTEL', 20, 16);
    }
  } catch (error) {
    setColor(pdf, COLORS.white);
    pdf.setFontSize(22);
    pdf.setFont('helvetica', 'bold');
    pdf.text('EXOTEL', 20, 16);
  }
  
  // Header title
  setColor(pdf, COLORS.white);
  pdf.setFontSize(16);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Debt Collection Transformation Report', pageWidth - 20, 12, { align: 'right' });
  
  pdf.setFontSize(12);
  pdf.setFont('helvetica', 'normal');
  pdf.text('Your Personalized ROI Analysis', pageWidth - 20, 18, { align: 'right' });
  
  return 35;
};

// Executive Summary section
const createExecutiveSummary = (pdf: jsPDF, inputData: CalculatorData, results: CalculatedResults, userInfo: ReportData['userInfo'], yPos: number): number => {
  const pageWidth = pdf.internal.pageSize.getWidth();
  
  // Background box for executive summary
  setColor(pdf, COLORS.extraLight, 'fill');
  pdf.roundedRect(15, yPos - 5, pageWidth - 30, 50, 3, 3, 'F');
  
  // Title
  setColor(pdf, COLORS.primary);
  pdf.setFontSize(20);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Executive Summary', 20, yPos + 5);
  
  yPos += 15;
  
  // Key insight
  setColor(pdf, COLORS.dark);
  pdf.setFontSize(14);
  pdf.setFont('helvetica', 'bold');
  pdf.text(`Transform Your Debt Collection with ${results.final.roi}% ROI`, 20, yPos);
  
  yPos += 8;
  
  // Summary content
  setColor(pdf, COLORS.medium);
  pdf.setFontSize(11);
  pdf.setFont('helvetica', 'normal');
  
  const summaryText = `Dear ${userInfo.email.split('@')[0]}, based on your current operation with ${inputData.collectionAgents} agents managing ${inputData.totalAccountsPerAgent} accounts each, Exotel's AI-powered debt collection platform can revolutionize your results. Our analysis shows you can achieve the same collection targets with ${results.final.agentSavings} fewer agents while increasing your yearly collection by ${inputData.currency} ${results.final.financialEquivalent.toLocaleString()}.`;
  
  const summaryLines = pdf.splitTextToSize(summaryText, pageWidth - 50);
  pdf.text(summaryLines, 20, yPos);
  yPos += summaryLines.length * 5;
  
  // Key metrics highlight
  yPos += 8;
  const metrics = [
    { label: 'Resolution Rate Improvement', value: `${((results.final.newResolutionRate - inputData.currentResolutionRate) / inputData.currentResolutionRate * 100).toFixed(1)}%`, color: COLORS.success },
    { label: 'Agent Efficiency Gain', value: `${results.final.agentSavings} fewer agents`, color: COLORS.secondary },
    { label: 'Additional Revenue', value: `${inputData.currency} ${results.final.financialEquivalent.toLocaleString()}`, color: COLORS.primary }
  ];
  
  metrics.forEach((metric, index) => {
    const xPos = 20 + (index * 60);
    setColor(pdf, metric.color);
    pdf.setFontSize(16);
    pdf.setFont('helvetica', 'bold');
    pdf.text(metric.value, xPos, yPos);
    
    setColor(pdf, COLORS.medium);
    pdf.setFontSize(9);
    pdf.setFont('helvetica', 'normal');
    pdf.text(metric.label, xPos, yPos + 6);
  });
  
  return yPos + 20;
};

// Problem statement section
const createProblemStatement = (pdf: jsPDF, inputData: CalculatorData, yPos: number): number => {
  const pageBreak = checkPageBreak(pdf, yPos, 60);
  yPos = pageBreak.yPos;
  
  // Section header
  setColor(pdf, COLORS.warning);
  pdf.setFontSize(18);
  pdf.setFont('helvetica', 'bold');
  pdf.text('The Challenge: Traditional Debt Collection Limitations', 20, yPos);
  
  yPos += 12;
  
  // Problem description
  setColor(pdf, COLORS.dark);
  pdf.setFontSize(11);
  pdf.setFont('helvetica', 'normal');
  
  const problems = [
    'Manual processes limiting agent productivity and resolution rates',
    'Inconsistent borrower engagement across multiple channels',
    'Reactive approach leading to longer collection cycles',
    'Limited visibility into borrower preferences and optimal contact times',
    'High operational costs with suboptimal resource allocation'
  ];
  
  problems.forEach((problem, index) => {
    // Problem icon (warning triangle)
    setColor(pdf, COLORS.warning, 'fill');
    pdf.triangle(25, yPos - 2, 25 - 2, yPos + 2, 25 + 2, yPos + 2, 'F');
    
    setColor(pdf, COLORS.dark);
    pdf.text(problem, 32, yPos);
    yPos += 7;
  });
  
  // Current state box
  yPos += 5;
  setColor(pdf, [255, 239, 234], 'fill'); // Light orange background
  pdf.roundedRect(20, yPos - 3, 150, 25, 2, 2, 'F');
  
  setColor(pdf, COLORS.dark);
  pdf.setFontSize(12);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Your Current State Analysis:', 25, yPos + 3);
  
  yPos += 8;
  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'normal');
  pdf.text(`• ${inputData.collectionAgents} agents handling ${inputData.totalAccountsPerAgent} accounts each`, 25, yPos);
  yPos += 5;
  pdf.text(`• Current resolution rate: ${inputData.currentResolutionRate}%`, 25, yPos);
  yPos += 5;
  pdf.text(`• Collection cycle: ${inputData.collectionCycleDays} days`, 25, yPos);
  yPos += 5;
  pdf.text(`• Yearly collection: ${inputData.currency} ${(inputData.collectionAgents * inputData.totalAccountsPerAgent * inputData.currentResolutionRate / 100 * inputData.averageDebtPerAccount).toLocaleString()}`, 25, yPos);
  
  return yPos + 15;
};

// Enhanced results comparison with visual charts
const createEnhancedResultsComparison = (pdf: jsPDF, inputData: CalculatorData, results: CalculatedResults, yPos: number): number => {
  const pageBreak = checkPageBreak(pdf, yPos, 80);
  yPos = pageBreak.yPos;
  
  // Section title
  setColor(pdf, COLORS.primary);
  pdf.setFontSize(18);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Transformation Results: Current vs. With Exotel', 20, yPos);
  
  yPos += 15;
  
  // Before/After comparison cards
  const cardWidth = 85;
  const cardHeight = 60;
  const cardSpacing = 10;
  
  // Current state card
  setColor(pdf, COLORS.light, 'fill');
  pdf.roundedRect(20, yPos, cardWidth, cardHeight, 3, 3, 'F');
  
  setColor(pdf, COLORS.dark);
  pdf.setFontSize(14);
  pdf.setFont('helvetica', 'bold');
  pdf.text('CURRENT STATE', 25, yPos + 8);
  
  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'normal');
  pdf.text(`Agents: ${inputData.collectionAgents}`, 25, yPos + 18);
  pdf.text(`Resolution Rate: ${inputData.currentResolutionRate}%`, 25, yPos + 25);
  pdf.text(`Yearly Resolutions:`, 25, yPos + 32);
  pdf.text(`${results.current.yearlyResolutions.toLocaleString()}`, 25, yPos + 38);
  pdf.text(`Yearly Collection:`, 25, yPos + 45);
  pdf.text(`${inputData.currency} ${results.current.yearlyCollection.toLocaleString()}`, 25, yPos + 51);
  
  // Arrow
  setColor(pdf, COLORS.secondary);
  pdf.setFontSize(20);
  pdf.text('→', 110, yPos + 35);
  
  // Future state card
  setColor(pdf, COLORS.primaryLight, 'fill');
  pdf.roundedRect(125, yPos, cardWidth, cardHeight, 3, 3, 'F');
  
  setColor(pdf, COLORS.white);
  pdf.setFontSize(14);
  pdf.setFont('helvetica', 'bold');
  pdf.text('WITH EXOTEL', 130, yPos + 8);
  
  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'normal');
  pdf.text(`Agents: ${results.final.newAgentCount}`, 130, yPos + 18);
  pdf.text(`Resolution Rate: ${results.final.newResolutionRate}%`, 130, yPos + 25);
  pdf.text(`Yearly Resolutions:`, 130, yPos + 32);
  pdf.text(`${results.final.totalYearlyResolutions.toLocaleString()}`, 130, yPos + 38);
  pdf.text(`Yearly Collection:`, 130, yPos + 45);
  pdf.text(`${inputData.currency} ${results.final.totalYearlyCollection.toLocaleString()}`, 130, yPos + 51);
  
  yPos += cardHeight + 15;
  
  // Improvement metrics
  setColor(pdf, COLORS.success, 'fill');
  pdf.roundedRect(20, yPos, 170, 30, 3, 3, 'F');
  
  setColor(pdf, COLORS.white);
  pdf.setFontSize(16);
  pdf.setFont('helvetica', 'bold');
  pdf.text('🎯 KEY IMPROVEMENTS', 25, yPos + 10);
  
  pdf.setFontSize(11);
  pdf.setFont('helvetica', 'normal');
  pdf.text(`💰 Additional Revenue: ${inputData.currency} ${results.final.financialEquivalent.toLocaleString()}`, 25, yPos + 18);
  pdf.text(`👥 Agent Optimization: ${results.final.agentSavings} fewer agents needed`, 25, yPos + 24);
  
  return yPos + 40;
};

// Detailed solution architecture
const createSolutionArchitecture = (pdf: jsPDF, inputData: CalculatorData, results: CalculatedResults, yPos: number): number => {
  const pageBreak = checkPageBreak(pdf, yPos, 60);
  yPos = pageBreak.yPos;
  
  setColor(pdf, COLORS.primary);
  pdf.setFontSize(18);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Exotel Solution Architecture', 20, yPos);
  
  yPos += 10;
  
  setColor(pdf, COLORS.medium);
  pdf.setFontSize(11);
  pdf.setFont('helvetica', 'normal');
  const introText = `Our comprehensive platform transforms your debt collection through four integrated pillars, specifically designed to address your current challenges with ${inputData.collectionAgents} agents and ${inputData.currentResolutionRate}% resolution rate.`;
  const introLines = pdf.splitTextToSize(introText, 170);
  pdf.text(introLines, 20, yPos);
  yPos += introLines.length * 5 + 10;
  
  const solutionPillars = [
    {
      number: '1',
      title: 'AI-Powered Automation Engine',
      subtitle: 'Intelligent Conversation Management',
      description: 'Deploy advanced voicebots and chatbots that handle routine collection calls 24/7, freeing your agents for complex cases. Our AI understands context, emotions, and payment capabilities to personalize every interaction.',
      features: [
        'Natural language processing for human-like conversations',
        'Emotion detection and empathy-driven responses',
        'Multi-language support (English, Hindi, Hinglish, Arabic, Tamil)',
        'Seamless agent handoff for complex negotiations',
        'Payment reminder automation with optimal timing'
      ],
      impact: `Potential to handle 60-70% of your routine calls automatically`
    },
    {
      number: '2',
      title: 'Omnichannel Orchestration Platform',
      subtitle: 'Unified Customer Journey Management',
      description: 'Create seamless borrower experiences across SMS, WhatsApp, email, voice, and in-person visits. Our platform ensures consistent messaging and optimal channel selection based on borrower preferences.',
      features: [
        'Smart channel routing based on borrower behavior',
        'Unified conversation history across all touchpoints',
        'Automated follow-up sequences with escalation logic',
        'Real-time campaign optimization and A/B testing',
        'Integration with field collection mobile apps'
      ],
      impact: `Expected to improve contact rates by 40-50%`
    },
    {
      number: '3',
      title: 'Intelligent Contact Center',
      subtitle: 'Agent Productivity Maximization',
      description: 'Empower your existing agents with AI-assisted tools, real-time coaching, and automated workflows that increase their efficiency and success rates.',
      features: [
        'AI-powered call scripting and real-time suggestions',
        'Automated quality monitoring and coaching',
        'Predictive dialing with optimal timing algorithms',
        'CRM integration with popular platforms (Salesforce, HubSpot)',
        'Performance analytics and agent ranking systems'
      ],
      impact: `Can increase agent productivity by 35-45%`
    },
    {
      number: '4',
      title: 'Data Intelligence & Analytics',
      subtitle: 'Predictive Collection Insights',
      description: 'Leverage machine learning algorithms to predict payment likelihood, optimize collection strategies, and identify high-value accounts for priority treatment.',
      features: [
        'Payment propensity scoring and risk assessment',
        'Optimal contact time prediction for each borrower',
        'Collection strategy recommendations based on borrower profiles',
        'Real-time dashboard with actionable insights',
        'Regulatory compliance monitoring and reporting'
      ],
      impact: `Typically improves resolution rates by 25-35%`
    }
  ];
  
  solutionPillars.forEach((pillar, index) => {
    const pageBreak = checkPageBreak(pdf, yPos, 80);
    yPos = pageBreak.yPos;
    
    // Pillar header with number circle
    setColor(pdf, COLORS.primary, 'fill');
    pdf.circle(30, yPos + 8, 10, 'F');
    setColor(pdf, COLORS.white);
    pdf.setFontSize(16);
    pdf.setFont('helvetica', 'bold');
    pdf.text(pillar.number, 30, yPos + 12, { align: 'center' });
    
    // Title and subtitle
    setColor(pdf, COLORS.primary);
    pdf.setFontSize(14);
    pdf.setFont('helvetica', 'bold');
    pdf.text(pillar.title, 45, yPos + 6);
    
    setColor(pdf, COLORS.secondary);
    pdf.setFontSize(11);
    pdf.setFont('helvetica', 'italic');
    pdf.text(pillar.subtitle, 45, yPos + 12);
    
    yPos += 18;
    
    // Description
    setColor(pdf, COLORS.dark);
    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'normal');
    const descLines = pdf.splitTextToSize(pillar.description, 145);
    pdf.text(descLines, 45, yPos);
    yPos += descLines.length * 4 + 5;
    
    // Features
    setColor(pdf, COLORS.medium);
    pdf.setFontSize(9);
    pillar.features.forEach((feature) => {
      pdf.text(`• ${feature}`, 50, yPos);
      yPos += 5;
    });
    
    // Impact highlight
    yPos += 3;
    setColor(pdf, COLORS.success, 'fill');
    pdf.roundedRect(45, yPos - 2, 140, 10, 2, 2, 'F');
    setColor(pdf, COLORS.white);
    pdf.setFontSize(9);
    pdf.setFont('helvetica', 'bold');
    pdf.text(`💡 ${pillar.impact}`, 50, yPos + 4);
    
    yPos += 15;
  });
  
  return yPos;
};

// Implementation roadmap
const createImplementationRoadmap = (pdf: jsPDF, yPos: number): number => {
  const pageBreak = checkPageBreak(pdf, yPos, 60);
  yPos = pageBreak.yPos;
  
  setColor(pdf, COLORS.primary);
  pdf.setFontSize(18);
  pdf.setFont('helvetica', 'bold');
  pdf.text('90-Day Implementation Roadmap', 20, yPos);
  
  yPos += 15;
  
  const phases = [
    {
      phase: 'Phase 1 (Days 1-30)',
      title: 'Foundation Setup',
      activities: [
        'Platform setup and CRM integration',
        'Agent training and onboarding',
        'Basic automation workflows deployment',
        'Initial AI chatbot configuration'
      ]
    },
    {
      phase: 'Phase 2 (Days 31-60)',
      title: 'Advanced Features Deployment',
      activities: [
        'Voicebot implementation and testing',
        'Omnichannel campaign setup',
        'Predictive analytics configuration',
        'Performance monitoring establishment'
      ]
    },
    {
      phase: 'Phase 3 (Days 61-90)',
      title: 'Optimization & Scale',
      activities: [
        'AI model fine-tuning based on your data',
        'Advanced workflow automation',
        'Performance optimization and scaling',
        'Full ROI realization and reporting'
      ]
    }
  ];
  
  phases.forEach((phase, index) => {
    // Phase header
    setColor(pdf, COLORS.secondary, 'fill');
    pdf.roundedRect(20, yPos, 170, 8, 2, 2, 'F');
    setColor(pdf, COLORS.white);
    pdf.setFontSize(11);
    pdf.setFont('helvetica', 'bold');
    pdf.text(`${phase.phase}: ${phase.title}`, 25, yPos + 5);
    
    yPos += 12;
    
    // Activities
    setColor(pdf, COLORS.dark);
    pdf.setFontSize(9);
    pdf.setFont('helvetica', 'normal');
    phase.activities.forEach((activity) => {
      pdf.text(`✓ ${activity}`, 25, yPos);
      yPos += 5;
    });
    
    yPos += 5;
  });
  
  return yPos;
};

// Enhanced footer with clickable demo link
const createEnhancedFooter = (pdf: jsPDF): void => {
  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();
  
  // Footer background with gradient effect
  for (let i = 0; i < 35; i++) {
    const alpha = (i / 35) * 0.8 + 0.2;
    const color = COLORS.primary.map(c => Math.round(c * alpha)) as [number, number, number];
    setColor(pdf, color, 'fill');
    pdf.rect(0, pageHeight - 35 + i, pageWidth, 1, 'F');
  }
  
  // Call to action
  setColor(pdf, COLORS.white);
  pdf.setFontSize(16);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Ready to Transform Your Debt Collection?', 20, pageHeight - 25);
  
  pdf.setFontSize(11);
  pdf.setFont('helvetica', 'normal');
  pdf.text('Contact us: sales@exotel.com | +91-80-47480000', 20, pageHeight - 18);
  
  // Clickable "Book a Demo" button
  const buttonX = pageWidth - 80;
  const buttonY = pageHeight - 30;
  const buttonWidth = 60;
  const buttonHeight = 12;
  
  // Button background
  setColor(pdf, COLORS.secondary, 'fill');
  pdf.roundedRect(buttonX, buttonY, buttonWidth, buttonHeight, 3, 3, 'F');
  
  // Button text
  setColor(pdf, COLORS.white);
  pdf.setFontSize(12);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Book a Demo', buttonX + buttonWidth/2, buttonY + 7, { align: 'center' });
  
  // Add clickable link annotation
  pdf.link(buttonX, buttonY, buttonWidth, buttonHeight, { url: 'https://exotel.com/request-a-demo/' });
  
  // Footer fine print
  setColor(pdf, COLORS.white);
  pdf.setFontSize(8);
  pdf.setFont('helvetica', 'normal');
  pdf.text('© 2024 Exotel. All rights reserved. Visit exotel.com for more information.', pageWidth/2, pageHeight - 8, { align: 'center' });
};

// Main enhanced PDF generation function
export const generateEnhancedPDFReport = async (data: ReportData): Promise<void> => {
  const { inputData, sliderData, results, userInfo } = data;
  
  const pdf = new jsPDF('p', 'mm', 'a4');
  
  // Generate enhanced PDF sections
  let yPos = await createEnhancedHeader(pdf);
  yPos = createExecutiveSummary(pdf, inputData, results, userInfo, yPos);
  yPos = createProblemStatement(pdf, inputData, yPos);
  yPos = createEnhancedResultsComparison(pdf, inputData, results, yPos);
  yPos = createSolutionArchitecture(pdf, inputData, results, yPos);
  yPos = createImplementationRoadmap(pdf, yPos);
  
  // Add enhanced footer to all pages
  const pageCount = pdf.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    pdf.setPage(i);
    createEnhancedFooter(pdf);
  }
  
  // Save the enhanced PDF
  const fileName = `Exotel_Debt_Collection_Transformation_Report_${new Date().toISOString().split('T')[0]}.pdf`;
  pdf.save(fileName);
};