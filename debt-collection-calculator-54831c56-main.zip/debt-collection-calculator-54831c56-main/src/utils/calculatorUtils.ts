
import { CalculatorData, SliderData, CalculatedResults } from "@/types/calculator";

export const calculateResults = (inputData: CalculatorData, sliderData: SliderData): CalculatedResults => {
  const cyclesPerYear = 365 / inputData.collectionCycleDays;
  const totalAccounts = inputData.collectionAgents * inputData.totalAccountsPerAgent;
  
  // Current performance calculations
  const currentYearlyResolutions = Math.ceil(((inputData.collectionAgents * inputData.totalAccountsPerAgent) * 12) * (inputData.currentResolutionRate / 100));
  const currentYearlyCollection = currentYearlyResolutions * inputData.averageDebtPerAccount;
  
  // Improvement calculations with percentage-based formula
  const appliedResolutionImprovement = sliderData.improvedResolutionRate;
  const appliedResourceOptimization = sliderData.resourceOptimization;
  const combinedImprovementFactor = (appliedResolutionImprovement + appliedResourceOptimization) / 100;
  
  // NEW CALCULATION: Resolution Rate + (Resolution Rate * Improvement Percentage)
  const newResolutionRate = inputData.currentResolutionRate + (inputData.currentResolutionRate * sliderData.improvedResolutionRate / 100);
  
  const newBaseResolutions = (inputData.collectionAgents * inputData.totalAccountsPerAgent * newResolutionRate) / 100;
  const newTimeReduction = (newBaseResolutions * inputData.collectionCycleDays) / 365;
  const newYearlyResolutions = Math.ceil(newBaseResolutions - newTimeReduction);
  
  const newYearlyCollection = newYearlyResolutions * inputData.averageDebtPerAccount;
  const financialGains = newYearlyCollection - currentYearlyCollection;
  
  // Final results with improvements
  const optimizedAgentCount = Math.floor(inputData.collectionAgents * (1 - sliderData.resourceOptimization / 100));
  const increasedCapability = Math.round(inputData.totalAccountsPerAgent * (1 + sliderData.resourceOptimization / 100));
  
  // Calculate "Savings with Exotel" section using optimized values
  const savingsBaseResolutions = (optimizedAgentCount * increasedCapability * newResolutionRate) / 100;
  const savingsTimeReduction = (savingsBaseResolutions * inputData.collectionCycleDays) / 365;
  const savingsYearlyResolutions = Math.ceil(savingsBaseResolutions - savingsTimeReduction);
  const savingsYearlyCollection = savingsYearlyResolutions * inputData.averageDebtPerAccount;
  
  // Calculate final resolutions using the new formula: [[Optimized Agents * Capacity per Agent] * 12] * New Resolution Rate %
  const finalYearlyResolutions = Math.ceil(((optimizedAgentCount * increasedCapability) * 12) * (newResolutionRate / 100));
  
  const finalYearlyCollection = finalYearlyResolutions * inputData.averageDebtPerAccount;
  
  const earlyResolutions = finalYearlyResolutions - currentYearlyResolutions;
  const financialEquivalent = finalYearlyCollection - currentYearlyCollection;
  const agentSavings = inputData.collectionAgents - optimizedAgentCount;
  
  const totalAnnualSavings = financialEquivalent + (agentSavings * 50000);
  const roi = (totalAnnualSavings / (inputData.collectionAgents * 50000)) * 100;

  return {
    current: {
      yearlyResolutions: Math.round(currentYearlyResolutions),
      yearlyCollection: Math.round(currentYearlyCollection),
    },
    improvement: {
      appliedResolutionImprovement,
      appliedResourceOptimization,
      combinedImprovementFactor: Math.round(combinedImprovementFactor * 100),
      earlyResolutions: Math.round(earlyResolutions),
      financialEquivalent: Math.round(financialEquivalent),
      agentSavings,
    },
    final: {
      newAgentCount: optimizedAgentCount,
      increasedCapability: increasedCapability,
      newResolutionRate: Math.round(newResolutionRate * 10) / 10, // Round to 1 decimal place
      earlyResolutions: Math.round(earlyResolutions),
      financialEquivalent: Math.round(financialEquivalent),
      agentSavings,
      totalYearlyResolutions: Math.round(finalYearlyResolutions),
      totalYearlyCollection: Math.round(finalYearlyCollection),
      totalAnnualSavings: Math.round(totalAnnualSavings),
      roi: Math.round(roi),
      savingsYearlyResolutions: Math.round(savingsYearlyResolutions),
      savingsYearlyCollection: Math.round(savingsYearlyCollection),
    },
  };
};
