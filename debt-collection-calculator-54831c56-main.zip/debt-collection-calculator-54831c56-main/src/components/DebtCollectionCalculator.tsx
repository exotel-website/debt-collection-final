
import { useState, useEffect } from "react";
import InputDataPane from "./calculator/InputDataPane";
import SliderPane from "./calculator/SliderPane";
import OutputPane from "./calculator/OutputPane";
import { Button } from "@/components/ui/button";
import { CalculatorData, SliderData, CalculatedResults } from "@/types/calculator";
import { calculateResults } from "@/utils/calculatorUtils";

const DebtCollectionCalculator = () => {
  const [inputData, setInputData] = useState<CalculatorData>({
    collectionAgents: 50,
    totalAccountsPerAgent: 100,
    currentResolutionRate: 20,
    averageDebtPerAccount: 10000,
    collectionCycleDays: 30,
    currency: "INR",
  });

  const [sliderData, setSliderData] = useState<SliderData>({
    improvedResolutionRate: 10,
    resourceOptimization: 15,
  });

  const [results, setResults] = useState<CalculatedResults>({
    current: { yearlyResolutions: 0, yearlyCollection: 0 },
    improvement: { 
      appliedResolutionImprovement: 0, 
      appliedResourceOptimization: 0, 
      combinedImprovementFactor: 0,
      earlyResolutions: 0,
      financialEquivalent: 0,
      agentSavings: 0
    },
    final: { 
      newAgentCount: 0, 
      increasedCapability: 0, 
      newResolutionRate: 0, 
      earlyResolutions: 0, 
      financialEquivalent: 0, 
      agentSavings: 0, 
      totalYearlyResolutions: 0, 
      totalYearlyCollection: 0, 
      totalAnnualSavings: 0, 
      roi: 0,
      savingsYearlyResolutions: 0,
      savingsYearlyCollection: 0
    }
  });

  useEffect(() => {
    const calculatedResults = calculateResults(inputData, sliderData);
    setResults(calculatedResults);
  }, [inputData, sliderData]);

  return (
    <div className="min-h-screen bg-muted/30 py-8 sm:py-12 px-4 sm:px-6">
      <div className="container mx-auto max-w-[1600px]">
        <div className="text-center mb-8 sm:mb-12">
          <h1 className="text-2xl sm:text-4xl lg:text-5xl font-bold mb-3 sm:mb-4 text-foreground px-4">
            Debt Collection Calculator
          </h1>
          <p className="text-sm sm:text-lg text-muted-foreground px-4">
            Calculate your potential savings with Exotel
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
          <InputDataPane 
            data={inputData} 
            onChange={setInputData} 
            results={results.current}
          />
          <SliderPane 
            data={sliderData} 
            onChange={setSliderData} 
            results={results.improvement}
            inputData={inputData}
          />
          <OutputPane 
            inputData={inputData}
            sliderData={sliderData}
            results={results.final}
          />
        </div>
      </div>
    </div>
  );
};

export default DebtCollectionCalculator;
