import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import heroImage from "@/assets/hero-debt-collection-professional.jpg";
import AnimatedCounter from "@/components/hero/AnimatedCounter";

const HeroSection = () => {
  const scrollToCalculator = () => {
    const calculatorElement = document.getElementById("calculator-section");
    calculatorElement?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section className="relative bg-gradient-to-br from-[#3172DF]/15 via-background to-[#6BE6C4]/15 py-12 sm:py-20 lg:py-24" style={{ backgroundImage: 'linear-gradient(45deg, rgba(49, 114, 223, 0.15) 0%, rgba(255, 255, 255, 1) 50%, rgba(107, 230, 196, 0.15) 100%)' }}>
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-start">
          {/* Left Content */}
          <div className="text-center lg:text-left">
            {/* Main Headline */}
            <h1 className="text-3xl sm:text-3xl lg:text-4xl xl:text-5xl font-bold mb-4 sm:mb-6 text-foreground leading-tight">
              Transform Your{" "}
              <span className="text-exotel-green">Debt Collection</span>{" "}
              Operations
            </h1>

            {/* Subheadline */}
            <p className="text-xl sm:text-2xl text-muted-foreground mb-6 sm:mb-8 font-medium">
              Maximize Recovery Rates, Minimize Costs
            </p>

            {/* Description */}
            <p className="text-base sm:text-lg text-muted-foreground mb-8 sm:mb-10 leading-relaxed">
              Discover how Exotel's AI-powered communication platform can help you 
              increase resolution rates, optimize your team size, and unlock significant 
              cost savings. Use our interactive calculator below to see your potential impact.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start items-stretch sm:items-center">
              <Button
                size="lg"
                onClick={scrollToCalculator}
                className="bg-exotel-green hover:bg-exotel-green-dark text-white font-semibold px-6 sm:px-8 py-4 sm:py-6 rounded-lg shadow-lg transition-all duration-200 group w-full sm:w-auto"
              >
                Try the Calculator
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Button>
              
              <Button
                size="lg"
                variant="outline"
                onClick={() => window.open('https://exotel.com/request-a-demo/', '_blank')}
                className="border-exotel-green text-exotel-green hover:bg-exotel-green/10 font-semibold px-6 sm:px-8 py-4 sm:py-6 rounded-lg w-full sm:w-auto"
              >
                Book a Demo
              </Button>
            </div>
          </div>

          {/* Right Image */}
          <div className="hidden lg:flex items-start justify-center lg:-mt-4">
            <img 
              src={heroImage} 
              alt="Professional debt collection representative" 
              className="w-full h-full object-cover rounded-2xl shadow-2xl max-h-[500px]"
            />
          </div>
        </div>

        {/* Trust Indicators - Single Row at Bottom */}
        <div className="mt-16 sm:mt-20 pt-8 border-t border-border">
          <p className="text-xs sm:text-sm text-muted-foreground mb-6 text-center">Trusted by leading enterprises</p>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 lg:gap-6">
            <Card className="p-4 text-center hover:shadow-lg hover:border-exotel-green/50 transition-all duration-300 group">
              <AnimatedCounter 
                end={25} 
                suffix="B+" 
                className="text-xl sm:text-2xl lg:text-3xl font-bold text-exotel-green mb-2 group-hover:scale-110 transition-transform duration-300"
              />
              <div className="text-xs sm:text-sm text-muted-foreground">Conversations handled annually</div>
            </Card>
            <Card className="p-4 text-center hover:shadow-lg hover:border-exotel-blue/50 transition-all duration-300 group">
              <AnimatedCounter 
                end={99.99} 
                suffix="%" 
                decimals={2}
                className="text-xl sm:text-2xl lg:text-3xl font-bold text-exotel-blue mb-2 group-hover:scale-110 transition-transform duration-300"
              />
              <div className="text-xs sm:text-sm text-muted-foreground">Uptime with native telco reliability</div>
            </Card>
            <Card className="p-4 text-center hover:shadow-lg hover:border-exotel-purple/50 transition-all duration-300 group">
              <AnimatedCounter 
                end={4} 
                suffix=" Billion+" 
                className="text-xl sm:text-2xl lg:text-3xl font-bold text-exotel-purple mb-2 group-hover:scale-110 transition-transform duration-300"
              />
              <div className="text-xs sm:text-sm text-muted-foreground">Resolutions using AI bots</div>
            </Card>
            <Card className="p-4 text-center hover:shadow-lg hover:border-exotel-green/50 transition-all duration-300 group">
              <AnimatedCounter 
                end={7000} 
                suffix="+" 
                className="text-xl sm:text-2xl lg:text-3xl font-bold text-exotel-green mb-2 group-hover:scale-110 transition-transform duration-300"
              />
              <div className="text-xs sm:text-sm text-muted-foreground">Businesses trust Exotel globally</div>
            </Card>
            <Card className="p-4 text-center col-span-2 md:col-span-3 lg:col-span-1 hover:shadow-lg hover:border-exotel-blue/50 transition-all duration-300 group">
              <AnimatedCounter 
                end={60} 
                suffix="%" 
                className="text-xl sm:text-2xl lg:text-3xl font-bold text-exotel-blue mb-2 group-hover:scale-110 transition-transform duration-300"
              />
              <div className="text-xs sm:text-sm text-muted-foreground">of India's voice infrastructure</div>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
