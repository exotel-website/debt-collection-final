import { TrendingUp, Users, Clock, DollarSign } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const features = [
  {
    icon: TrendingUp,
    title: "Boost Resolution Rates",
    description: "Leverage AI-powered conversations and intelligent routing to increase successful debt resolutions by up to 30%.",
    color: "text-exotel-green",
    gradient: "from-exotel-green/80 to-exotel-green",
    shadow: "shadow-[0_8px_16px_rgba(107,230,196,0.3)]",
  },
  {
    icon: Users,
    title: "Optimize Team Size",
    description: "Handle more accounts with fewer agents through automation and smart workflows, reducing operational overhead.",
    color: "text-exotel-blue",
    gradient: "from-exotel-blue/80 to-exotel-blue",
    shadow: "shadow-[0_8px_16px_rgba(49,114,223,0.3)]",
  },
  {
    icon: Clock,
    title: "Accelerate Collections",
    description: "Reduce collection cycles with timely, automated outreach across voice, SMS, and WhatsApp channels.",
    color: "text-exotel-purple",
    gradient: "from-exotel-purple/80 to-exotel-purple",
    shadow: "shadow-[0_8px_16px_rgba(147,51,234,0.3)]",
  },
  {
    icon: DollarSign,
    title: "Maximize Savings",
    description: "Unlock significant cost savings through improved efficiency, reduced agent requirements, and faster resolutions.",
    color: "text-exotel-green-dark",
    gradient: "from-exotel-green-dark/80 to-exotel-green-dark",
    shadow: "shadow-[0_8px_16px_rgba(5,150,105,0.3)]",
  },
];

const FeaturesSection = () => {
  return (
    <section className="py-12 sm:py-16 lg:py-24 bg-background">
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-8 sm:mb-12 lg:mb-16">
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold mb-3 sm:mb-4 text-foreground">
            Why Choose <span className="text-exotel-green">Exotel</span>?
          </h2>
          <p className="text-base sm:text-lg text-muted-foreground px-4">
            Our platform delivers measurable results that transform your debt collection operations
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6 lg:gap-8">
          {features.map((feature) => {
            const Icon = feature.icon;
            return (
              <Card 
                key={feature.title}
                className="border-border hover:border-exotel-green/50 transition-all duration-300 hover:shadow-lg group"
              >
                <CardHeader className="p-4 sm:p-6 text-center">
                  <div className={`relative w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-gradient-to-br ${feature.gradient} flex items-center justify-center mb-3 sm:mb-4 ${feature.shadow} overflow-hidden group-hover:scale-110 transition-transform duration-300 mx-auto`}>
                    {/* Glossy overlay effect */}
                    <div className="absolute inset-0 bg-gradient-to-br from-white/40 via-transparent to-transparent rounded-2xl"></div>
                    <div className="absolute inset-0 bg-gradient-to-t from-black/10 via-transparent to-transparent rounded-2xl"></div>
                    <Icon className={`h-6 w-6 sm:h-8 sm:w-8 text-white relative z-10 drop-shadow-lg`} />
                  </div>
                  <CardTitle className="text-lg sm:text-xl lg:text-2xl mb-2">{feature.title}</CardTitle>
                  <CardDescription className="text-sm sm:text-base">
                    {feature.description}
                  </CardDescription>
                </CardHeader>
              </Card>
            );
          })}
        </div>

        {/* Additional Value Props */}
        <div className="mt-8 sm:mt-12 lg:mt-16 text-center px-4">
          <div className="inline-flex flex-wrap gap-3 sm:gap-4 lg:gap-6 justify-center items-center text-xs sm:text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-exotel-green"></div>
              <span>No Setup Fees</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-exotel-blue"></div>
              <span>Pay-as-you-go Pricing</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-exotel-purple"></div>
              <span>24/7 Support</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-exotel-green-dark"></div>
              <span>Quick Integration</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
