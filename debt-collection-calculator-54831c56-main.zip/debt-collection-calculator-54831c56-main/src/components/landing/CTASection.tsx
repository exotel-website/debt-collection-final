import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const CTASection = () => {
  return (
    <section className="py-12 sm:py-16 lg:py-24 bg-gradient-to-br from-[#3172DF]/15 via-background to-[#6BE6C4]/15" style={{ backgroundImage: 'linear-gradient(45deg, rgba(49, 114, 223, 0.15) 0%, rgba(255, 255, 255, 1) 50%, rgba(107, 230, 196, 0.15) 100%)' }}>
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-4xl mx-auto">
          <h2 className="text-2xl sm:text-3xl lg:text-5xl font-bold mb-4 sm:mb-6 text-foreground px-4">
            Ready to Transform Your Collections?
          </h2>
          <p className="text-sm sm:text-base lg:text-lg text-muted-foreground mb-8 sm:mb-10 max-w-3xl mx-auto leading-relaxed px-4">
            Join 2000+ businesses already benefiting from Exotel's intelligent 
            communication platform. Get started today with a personalized demo.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-stretch sm:items-center px-4">
            <Button
              size="lg"
              onClick={() => window.open('https://exotel.com/request-a-demo/', '_blank')}
              className="bg-exotel-green hover:bg-exotel-green-dark text-white font-semibold px-6 sm:px-8 py-4 sm:py-6 rounded-lg shadow-lg transition-all duration-200 group w-full sm:w-auto"
            >
              Schedule Your Demo
              <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </Button>
            
            <Button
              size="lg"
              variant="outline"
              onClick={() => window.open('https://exotel.com/use-cases/debt-collection/', '_blank')}
              className="border-exotel-green text-exotel-green hover:bg-exotel-green/10 font-semibold px-6 sm:px-8 py-4 sm:py-6 rounded-lg w-full sm:w-auto"
            >
              Learn More
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;
