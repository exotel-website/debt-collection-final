import * as React from "react"
import * as TooltipPrimitive from "@radix-ui/react-tooltip"
import { useIsMobile } from "@/hooks/use-mobile"
import { cn } from "@/lib/utils"
import { HelpCircle, Info } from "lucide-react"

interface ResponsiveTooltipProps {
  content: string
  children?: React.ReactNode
  iconSize?: "sm" | "md" | "lg"
  className?: string
}

const ResponsiveTooltip = ({ 
  content, 
  children, 
  iconSize = "sm",
  className 
}: ResponsiveTooltipProps) => {
  const isMobile = useIsMobile()
  const [isOpen, setIsOpen] = React.useState(false)

  const iconSizeClasses = {
    sm: "w-3 h-3",
    md: "w-4 h-4", 
    lg: "w-5 h-5"
  }

  const touchAreaClasses = {
    sm: "p-1 -m-1",
    md: "p-1.5 -m-1.5",
    lg: "p-2 -m-2"
  }

  if (isMobile) {
    return (
      <div className="relative inline-flex">
        <button
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          className={cn(
            "touch-manipulation transition-colors rounded-full",
            "hover:bg-muted/50 active:bg-muted",
            touchAreaClasses[iconSize],
            className
          )}
          aria-label="Show information"
        >
          {children || (
            <Info className={cn(
              iconSizeClasses[iconSize],
              "text-muted-foreground/70"
            )} />
          )}
        </button>
        
        {isOpen && (
          <div className={cn(
            "absolute z-50 top-full left-1/2 transform -translate-x-1/2 mt-2",
            "bg-popover border rounded-lg shadow-lg p-3 max-w-xs",
            "text-sm text-popover-foreground animate-in fade-in-0 zoom-in-95"
          )}>
            <div className="relative">
              <p className="leading-relaxed">{content}</p>
              <div className="absolute -top-5 left-1/2 transform -translate-x-1/2">
                <div className="w-0 h-0 border-l-4 border-r-4 border-b-4 border-transparent border-b-border"></div>
                <div className="w-0 h-0 border-l-4 border-r-4 border-b-4 border-transparent border-b-popover -mt-px"></div>
              </div>
            </div>
          </div>
        )}
        
        {isOpen && (
          <div 
            className="fixed inset-0 z-40" 
            onClick={() => setIsOpen(false)}
            aria-hidden="true"
          />
        )}
      </div>
    )
  }

  return (
    <TooltipPrimitive.Root delayDuration={300}>
      <TooltipPrimitive.Trigger asChild>
        <button
          type="button"
          className={cn(
            "transition-colors rounded-full p-0.5 -m-0.5",
            "hover:bg-muted/50 focus:bg-muted focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1",
            className
          )}
        >
          {children || (
            <HelpCircle className={cn(
              iconSizeClasses[iconSize],
              "text-muted-foreground/60"
            )} />
          )}
        </button>
      </TooltipPrimitive.Trigger>
      <TooltipPrimitive.Content
        sideOffset={8}
        className={cn(
          "z-50 overflow-hidden rounded-md border bg-popover px-3 py-2",
          "text-sm text-popover-foreground shadow-md max-w-xs",
          "animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out",
          "data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95",
          "data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2",
          "data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2"
        )}
        collisionPadding={8}
        avoidCollisions={true}
      >
        <p className="leading-relaxed">{content}</p>
        <TooltipPrimitive.Arrow className="fill-popover" />
      </TooltipPrimitive.Content>
    </TooltipPrimitive.Root>
  )
}

export { ResponsiveTooltip }