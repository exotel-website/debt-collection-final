
import { TrendingUp, TrendingDown } from 'lucide-react';

interface ImprovementBadgeProps {
  value: number;
  label: string;
  isPercentage?: boolean;
  showTrend?: boolean;
}

const ImprovementBadge = ({ 
  value, 
  label, 
  isPercentage = false, 
  showTrend = true 
}: ImprovementBadgeProps) => {
  const isPositive = value > 0;
  
  // Round percentage values to 1 decimal place to avoid floating point precision issues
  const roundedValue = isPercentage ? Math.round(Math.abs(value) * 10) / 10 : Math.abs(value);
  const displayValue = isPercentage ? `${roundedValue}%` : roundedValue.toLocaleString('en-IN');
  
  return (
    <div className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
      isPositive 
        ? 'bg-green-100 text-green-800 border border-green-200' 
        : 'bg-red-100 text-red-800 border border-red-200'
    }`}>
      {showTrend && (
        isPositive ? (
          <TrendingUp className="w-3 h-3" />
        ) : (
          <TrendingDown className="w-3 h-3" />
        )
      )}
      <span>{isPositive ? '+' : '-'}{displayValue}</span>
      <span className="text-muted-foreground ml-1">{label}</span>
    </div>
  );
};

export default ImprovementBadge;
