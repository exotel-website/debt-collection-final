
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ResponsiveTooltip } from "@/components/ui/responsive-tooltip";
import { Clock } from 'lucide-react';

const CollectionCycleInput = () => {
  return (
    <div className="space-y-1">
      <Label htmlFor="cycle" className="text-xs sm:text-sm font-medium text-muted-foreground flex items-center gap-2">
        <Clock className="w-3 h-3" />
        Collection Cycle (Days)
        <ResponsiveTooltip 
          content="Standard collection cycle duration (fixed at 30 days)"
          iconSize="sm"
        />
      </Label>
      <Input
        id="cycle"
        type="number"
        value={30}
        disabled
        className="border-border h-7 sm:h-9 text-xs sm:text-sm bg-muted/50 text-muted-foreground cursor-not-allowed"
      />
    </div>
  );
};

export default CollectionCycleInput;
