
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ResponsiveTooltip } from "@/components/ui/responsive-tooltip";
import { FileText } from 'lucide-react';
import { CalculatorData } from "@/types/calculator";

interface AccountsInputProps {
  value: number | string;
  onChange: (field: keyof CalculatorData, value: number | string) => void;
  onNumberInputChange: (field: keyof CalculatorData, inputValue: string) => void;
  getDisplayValue: (value: number | string) => string;
}

const AccountsInput = ({ value, onChange, onNumberInputChange, getDisplayValue }: AccountsInputProps) => {
  return (
    <div className="space-y-1">
      <Label htmlFor="accounts" className="text-xs sm:text-sm font-medium text-muted-foreground flex items-center gap-2">
        <FileText className="w-3 h-3" />
        Accounts (Per Agent)
        <ResponsiveTooltip 
          content="Average number of accounts handled by each agent (1-5,000)"
          iconSize="sm"
        />
      </Label>
      <Input
        id="accounts"
        type="number"
        value={getDisplayValue(value)}
        onChange={(e) => {
          const inputValue = e.target.value;
          // Only allow positive whole numbers up to 5,000
          if (inputValue === '' || (/^\d+$/.test(inputValue) && parseInt(inputValue) > 0 && parseInt(inputValue) <= 5000)) {
            onNumberInputChange('totalAccountsPerAgent', inputValue);
          }
        }}
        onKeyDown={(e) => {
          // Prevent minus, plus, decimal point, and 'e' key
          if (['-', '+', '.', 'e', 'E'].includes(e.key)) {
            e.preventDefault();
          }
        }}
        placeholder="Enter accounts per agent"
        min="1"
        max="5000"
        className="border-border h-7 sm:h-9 text-xs sm:text-sm focus:ring-2 focus:ring-ring"
      />
    </div>
  );
};

export default AccountsInput;
