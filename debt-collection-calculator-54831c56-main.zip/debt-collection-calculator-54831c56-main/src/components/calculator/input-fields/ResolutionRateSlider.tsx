
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { ResponsiveTooltip } from "@/components/ui/responsive-tooltip";
import { Target } from 'lucide-react';
import { CalculatorData } from "@/types/calculator";

interface ResolutionRateSliderProps {
  value: number;
  onChange: (field: keyof CalculatorData, value: number | string) => void;
}

const ResolutionRateSlider = ({ value, onChange }: ResolutionRateSliderProps) => {
  const handleResolutionRateChange = (newValue: number[]) => {
    onChange('currentResolutionRate', newValue[0]);
  };

  return (
    <div className="space-y-1">
      <Label className="text-xs sm:text-sm font-medium text-muted-foreground flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <Target className="w-3 h-3" />
          <span>Resolution Rate</span>
          <ResponsiveTooltip 
            content="Percentage of accounts successfully resolved by your team"
            iconSize="sm"
          />
        </div>
        <span className="text-sm sm:text-base font-bold text-foreground bg-muted px-1.5 sm:px-2 py-0.5 rounded-full">
          {value}%
        </span>
      </Label>
      <div className="mt-2 sm:mt-3">
        <Slider
          value={[value]}
          onValueChange={handleResolutionRateChange}
          max={70}
          min={10}
          step={1}
          className="w-full"
        />
        <div className="flex justify-between text-xs text-muted-foreground mt-1">
          <span>10%</span>
          <span>70%</span>
        </div>
      </div>
    </div>
  );
};

export default ResolutionRateSlider;
