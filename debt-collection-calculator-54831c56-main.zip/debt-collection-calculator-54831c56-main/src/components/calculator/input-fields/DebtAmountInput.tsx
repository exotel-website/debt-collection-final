
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ResponsiveTooltip } from "@/components/ui/responsive-tooltip";
import { DollarSign } from 'lucide-react';
import { CalculatorData } from "@/types/calculator";

interface DebtAmountInputProps {
  debtValue: number | string;
  currency: string;
  onChange: (field: keyof CalculatorData, value: number | string) => void;
  onNumberInputChange: (field: keyof CalculatorData, inputValue: string) => void;
  getDisplayValue: (value: number | string) => string;
}

const DebtAmountInput = ({ debtValue, currency, onChange, onNumberInputChange, getDisplayValue }: DebtAmountInputProps) => {
  return (
    <div className="space-y-1">
      <Label htmlFor="debt" className="text-xs sm:text-sm font-medium text-muted-foreground flex items-center gap-2">
        <DollarSign className="w-3 h-3" />
        Avg Debt Per Account
        <ResponsiveTooltip 
          content="Average outstanding debt amount for each account (1-1,000,000,000)"
          iconSize="sm"
        />
      </Label>
      <div className="flex gap-1.5">
        <Select value={currency} onValueChange={(value) => onChange('currency', value)}>
          <SelectTrigger className="w-12 sm:w-14 border-border h-7 sm:h-9 text-xs sm:text-sm">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="INR">₹</SelectItem>
            <SelectItem value="USD">$</SelectItem>
            <SelectItem value="EUR">€</SelectItem>
          </SelectContent>
        </Select>
        <Input
          id="debt"
          type="number"
          value={getDisplayValue(debtValue)}
          onChange={(e) => {
            const inputValue = e.target.value;
            // Only allow positive whole numbers up to 1 billion
            if (inputValue === '' || (/^\d+$/.test(inputValue) && parseInt(inputValue) > 0 && parseInt(inputValue) <= 1000000000)) {
              onNumberInputChange('averageDebtPerAccount', inputValue);
            }
          }}
          onKeyDown={(e) => {
            // Prevent minus, plus, decimal point, and 'e' key
            if (['-', '+', '.', 'e', 'E'].includes(e.key)) {
              e.preventDefault();
            }
          }}
          placeholder="Enter debt amount"
          min="1"
          max="1000000000"
          className="flex-1 border-border h-7 sm:h-9 text-xs sm:text-sm focus:ring-2 focus:ring-ring"
        />
      </div>
    </div>
  );
};

export default DebtAmountInput;
