
import { Target } from 'lucide-react';
import AnimatedCounter from './AnimatedCounter';

interface CurrentPerformanceSectionProps {
  yearlyResolutions: number;
  yearlyCollection: number;
  currency: string;
}

const CurrentPerformanceSection = ({ yearlyResolutions, yearlyCollection, currency }: CurrentPerformanceSectionProps) => {
  return (
    <div className="mt-auto p-2 sm:p-3 bg-gradient-to-r from-red-50 to-rose-50 border-2 border-red-400 rounded-xl shadow-md">
      <h3 className="font-bold text-red-800 mb-1 sm:mb-2 text-center text-xs sm:text-sm flex items-center justify-center gap-2">
        <Target className="w-3 h-3" />
        Current Performance
      </h3>
      <div className="space-y-1 sm:space-y-2">
        <div className="flex justify-between items-center p-1.5 bg-white/50 rounded-lg">
          <span className="text-red-700 font-medium text-xs">Yearly Resolutions:</span>
          <span className="font-bold text-red-900 text-xs">
            <AnimatedCounter value={yearlyResolutions} />
          </span>
        </div>
        <div className="flex justify-between items-center p-1.5 bg-white/50 rounded-lg">
          <span className="text-red-700 font-medium text-xs">Yearly Collection:</span>
          <span className="font-bold text-red-900 text-xs">
            <AnimatedCounter 
              value={yearlyCollection} 
              prefix={currency === 'INR' ? '₹' : currency === 'USD' ? '$' : '€'} 
            />
          </span>
        </div>
      </div>
    </div>
  );
};

export default CurrentPerformanceSection;
