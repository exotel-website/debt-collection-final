
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { SliderData, CalculatorData } from "@/types/calculator";
import { TrendingUp, Zap, HelpCircle, Settings } from 'lucide-react';
import AnimatedCounter from './AnimatedCounter';
import ImprovementBadge from './ImprovementBadge';

interface SliderPaneProps {
  data: SliderData;
  onChange: (data: SliderData) => void;
  results: {
    appliedResolutionImprovement: number;
    appliedResourceOptimization: number;
    combinedImprovementFactor: number;
    earlyResolutions: number;
    financialEquivalent: number;
    agentSavings: number;
  };
  inputData: CalculatorData;
}

const SliderPane = ({ data, onChange, results, inputData }: SliderPaneProps) => {
  const handleSliderChange = (field: keyof SliderData, value: number[]) => {
    onChange({ ...data, [field]: value[0] });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: inputData.currency,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('en-IN').format(num);
  };

  return (
    <TooltipProvider>
      <Card className="h-full border-2 border-border flex flex-col shadow-lg bg-card">
        <CardHeader className="pb-1 sm:pb-2 p-2 sm:p-4">
          <CardTitle className="text-sm sm:text-base font-semibold text-foreground flex items-center gap-2">
            <Settings className="w-4 h-4 text-exotel-teal" />
            Improvement with Exotel
          </CardTitle>
        </CardHeader>
        <CardContent className="flex-1 flex flex-col p-2 sm:p-4 pt-0">
          <div className="space-y-4 sm:space-y-6 flex-1">
            <div>
              <Label className="text-xs sm:text-sm font-medium flex items-center justify-between mb-2 sm:mb-3">
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-3 h-3 text-exotel-teal" />
                  <span className="text-muted-foreground">Resolution Rate Boost</span>
                  <Tooltip>
                    <TooltipTrigger>
                      <HelpCircle className="w-3 h-3 text-muted-foreground/60" />
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Percentage improvement in resolution rate with Exotel's AI-powered solutions</p>
                    </TooltipContent>
                  </Tooltip>
                </div>
                <ImprovementBadge 
                  value={data.improvedResolutionRate} 
                  label="boost" 
                  isPercentage={true}
                />
              </Label>
              <p className="text-xs text-muted-foreground mb-2">% improvement over current rate</p>
              <div className="mt-2 sm:mt-3">
                <Slider
                  value={[data.improvedResolutionRate]}
                  onValueChange={(value) => handleSliderChange('improvedResolutionRate', value)}
                  max={30}
                  min={5}
                  step={5}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>5%</span>
                  <span>30%</span>
                </div>
              </div>
            </div>

            <div>
              <Label className="text-xs sm:text-sm font-medium flex items-center justify-between mb-2 sm:mb-3">
                <div className="flex items-center gap-2">
                  <Zap className="w-3 h-3 text-exotel-teal" />
                  <span className="text-muted-foreground">Resource Optimization</span>
                  <Tooltip>
                    <TooltipTrigger>
                      <HelpCircle className="w-3 h-3 text-muted-foreground/60" />
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Efficiency gains through automation and optimized workflows</p>
                    </TooltipContent>
                  </Tooltip>
                </div>
                <ImprovementBadge 
                  value={data.resourceOptimization} 
                  label="efficiency" 
                  isPercentage={true}
                />
              </Label>
              <div className="mt-2 sm:mt-3">
                <Slider
                  value={[data.resourceOptimization]}
                  onValueChange={(value) => handleSliderChange('resourceOptimization', value)}
                  max={30}
                  min={5}
                  step={5}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>5%</span>
                  <span>30%</span>
                </div>
              </div>
            </div>
          </div>

          {/* Enhanced Annual Performance Gains Section */}
          <div className="mt-auto p-2 sm:p-3 bg-gradient-to-r from-blue-50 to-sky-50 border-2 border-blue-400 rounded-xl shadow-md">
            <h3 className="font-bold text-blue-800 mb-1 sm:mb-2 text-center text-xs sm:text-sm flex items-center justify-center gap-2">
              <TrendingUp className="w-3 h-3" />
              Annual Performance Gains
            </h3>
            <div className="space-y-1 sm:space-y-2">
              <div className="flex justify-between items-center p-1.5 bg-white/50 rounded-lg">
                <span className="text-blue-700 font-medium text-xs">Additional Resolutions:</span>
                <span className="font-bold text-blue-900 text-xs">
                  <AnimatedCounter value={results.earlyResolutions} prefix="+" />
                </span>
              </div>
              <div className="flex justify-between items-center p-1.5 bg-white/50 rounded-lg">
                <span className="text-blue-700 font-medium text-xs">Extra Revenue:</span>
                <span className="font-bold text-blue-900 text-xs">
                  <AnimatedCounter 
                    value={results.financialEquivalent} 
                    prefix={inputData.currency === 'INR' ? '+₹' : inputData.currency === 'USD' ? '+$' : '+€'} 
                  />
                </span>
              </div>
              <div className="flex justify-between items-center p-1.5 bg-white/50 rounded-lg">
                <span className="text-blue-700 font-medium text-xs">Resource Savings:</span>
                <span className="font-bold text-blue-900 text-xs">
                  <AnimatedCounter value={results.agentSavings} suffix=" agents" />
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </TooltipProvider>
  );
};

export default SliderPane;
