
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { CalculatorData, SliderData } from "@/types/calculator";
import { CheckCircle, Users, Target, TrendingUp, HelpCircle } from 'lucide-react';
import AnimatedCounter from './AnimatedCounter';
import ImprovementBadge from './ImprovementBadge';
// import { usePdfReport } from '@/hooks/usePdfReport'; // Removed for now

interface OutputPaneProps {
  inputData: CalculatorData;
  sliderData: SliderData;
  results: {
    newAgentCount: number;
    increasedCapability: number;
    newResolutionRate: number;
    earlyResolutions: number;
    financialEquivalent: number;
    agentSavings: number;
    totalYearlyResolutions: number;
    totalYearlyCollection: number;
    totalAnnualSavings: number;
    roi: number;
    savingsYearlyResolutions: number;
    savingsYearlyCollection: number;
  };
}

const OutputPane = ({ inputData, sliderData, results }: OutputPaneProps) => {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: inputData.currency,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('en-IN').format(num);
  };

  return (
    <TooltipProvider>
      <Card className="h-full border-2 border-border flex flex-col shadow-lg bg-card">
        <CardHeader className="pb-1 sm:pb-2 p-2 sm:p-4">
          <CardTitle className="text-sm sm:text-base font-semibold text-foreground flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-green-600" />
            With Exotel Results
          </CardTitle>
        </CardHeader>
        <CardContent className="flex-1 flex flex-col p-2 sm:p-4 pt-0">
          {/* Optimized Setup - Clean Layout */}
          <div className="space-y-3 flex-1">
            {/* Optimized Agents */}
            <div className="bg-muted/20 rounded-lg p-3 border border-border/50">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm font-medium text-muted-foreground">Optimized Agents</span>
                  <Tooltip>
                    <TooltipTrigger>
                      <HelpCircle className="w-3 h-3 text-muted-foreground/60" />
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Reduced number of agents needed through resource optimization and efficiency gains</p>
                    </TooltipContent>
                  </Tooltip>
                </div>
                <span className="text-lg font-bold text-foreground">
                  <AnimatedCounter value={results.newAgentCount} />
                </span>
              </div>
              <div className="text-xs text-green-700 bg-green-50 px-2 py-1 rounded border border-green-200">
                <span className="font-medium">
                  {inputData.collectionAgents - results.newAgentCount} agents saved
                </span>
              </div>
            </div>

            {/* Capacity per Agent */}
            <div className="bg-muted/20 rounded-lg p-3 border border-border/50">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Target className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm font-medium text-muted-foreground">Capacity per Agent</span>
                  <Tooltip>
                    <TooltipTrigger>
                      <HelpCircle className="w-3 h-3 text-muted-foreground/60" />
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Increased number of accounts each agent can handle through improved efficiency</p>
                    </TooltipContent>
                  </Tooltip>
                </div>
                <span className="text-lg font-bold text-foreground">
                  <AnimatedCounter value={results.increasedCapability} />
                </span>
              </div>
              <div className="text-xs text-green-700 bg-green-50 px-2 py-1 rounded border border-green-200">
                <span className="font-medium">
                  +{results.increasedCapability - inputData.totalAccountsPerAgent} more accounts
                </span>
              </div>
            </div>

            {/* New Resolution Rate */}
            <div className="bg-muted/20 rounded-lg p-3 border border-border/50">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm font-medium text-muted-foreground">New Resolution Rate</span>
                  <Tooltip>
                    <TooltipTrigger>
                      <HelpCircle className="w-3 h-3 text-muted-foreground/60" />
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Improved resolution rate achieved through Exotel's AI-powered solutions and automation</p>
                    </TooltipContent>
                  </Tooltip>
                </div>
                <span className="text-lg font-bold text-exotel-teal">
                  <AnimatedCounter value={results.newResolutionRate} suffix="%" decimals={1} />
                </span>
              </div>
              <div className="text-xs text-green-700 bg-green-50 px-2 py-1 rounded border border-green-200">
                <span className="font-medium">
                  +{(results.newResolutionRate - inputData.currentResolutionRate).toFixed(1)}% improvement
                </span>
              </div>
            </div>
          </div>

          {/* Enhanced Performance Section */}
          <div className="mt-auto p-2 sm:p-3 bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-400 rounded-xl shadow-md">
            <h3 className="font-bold text-green-800 mb-1 sm:mb-2 text-center text-xs sm:text-sm flex items-center justify-center gap-2">
              <CheckCircle className="w-3 h-3" />
              Enhanced Performance
            </h3>
            <div className="space-y-1 sm:space-y-2">
              <div className="flex justify-between items-center p-1.5 bg-white/50 rounded-lg">
                <div className="flex items-center gap-1">
                  <span className="text-green-700 font-medium text-xs">Total Resolutions:</span>
                  <Tooltip>
                    <TooltipTrigger>
                      <HelpCircle className="w-2 h-2 text-green-600/60" />
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Total number of debt accounts resolved annually with Exotel's optimized setup</p>
                    </TooltipContent>
                  </Tooltip>
                </div>
                <span className="font-bold text-green-900 text-xs">
                  <AnimatedCounter value={results.totalYearlyResolutions} />
                </span>
              </div>
              <div className="flex justify-between items-center p-1.5 bg-white/50 rounded-lg">
                <div className="flex items-center gap-1">
                  <span className="text-green-700 font-medium text-xs">Total Collection:</span>
                  <Tooltip>
                    <TooltipTrigger>
                      <HelpCircle className="w-2 h-2 text-green-600/60" />
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Total annual debt collection amount achieved with improved resolution rates</p>
                    </TooltipContent>
                  </Tooltip>
                </div>
                <span className="font-bold text-green-900 text-xs">
                  <AnimatedCounter 
                    value={results.totalYearlyCollection} 
                    prefix={inputData.currency === 'INR' ? '₹' : inputData.currency === 'USD' ? '$' : '€'} 
                  />
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </TooltipProvider>
  );
};

export default OutputPane;
