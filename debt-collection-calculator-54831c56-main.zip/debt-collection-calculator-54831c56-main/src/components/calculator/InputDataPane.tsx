
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TooltipProvider } from "@/components/ui/tooltip";
import { CalculatorData } from "@/types/calculator";
import { FileText } from 'lucide-react';
import TeamSizeInput from './input-fields/TeamSizeInput';
import AccountsInput from './input-fields/AccountsInput';
import ResolutionRateSlider from './input-fields/ResolutionRateSlider';
import DebtAmountInput from './input-fields/DebtAmountInput';
import CollectionCycleInput from './input-fields/CollectionCycleInput';
import CurrentPerformanceSection from './CurrentPerformanceSection';

interface InputDataPaneProps {
  data: CalculatorData;
  onChange: (data: CalculatorData) => void;
  results: {
    yearlyResolutions: number;
    yearlyCollection: number;
  };
}

const InputDataPane = ({ data, onChange, results }: InputDataPaneProps) => {
  const handleInputChange = (field: keyof CalculatorData, value: number | string) => {
    onChange({ ...data, [field]: value });
  };

  const handleNumberInputChange = (field: keyof CalculatorData, inputValue: string) => {
    // If the input is empty, set to empty string for better UX
    if (inputValue === '') {
      handleInputChange(field, '');
      return;
    }
    
    // Convert to number and validate
    const numValue = Number(inputValue);
    if (!isNaN(numValue) && numValue >= 0) {
      handleInputChange(field, numValue);
    }
  };

  const getDisplayValue = (value: number | string): string => {
    // Show empty string instead of 0 for better UX
    if (value === 0 || value === '') return '';
    return String(value);
  };

  return (
    <TooltipProvider>
      <Card className="h-full border-2 border-border flex flex-col shadow-lg bg-card">
        <CardHeader className="pb-1 sm:pb-2 p-2 sm:p-4">
          <CardTitle className="text-sm sm:text-base font-semibold text-foreground flex items-center gap-2">
            <FileText className="w-4 h-4 text-muted-foreground" />
            Your Current Data
          </CardTitle>
        </CardHeader>
        <CardContent className="flex-1 flex flex-col p-2 sm:p-4 pt-0">
          <div className="space-y-2 sm:space-y-3 flex-1">
            <TeamSizeInput
              value={data.collectionAgents}
              onChange={handleInputChange}
              onNumberInputChange={handleNumberInputChange}
              getDisplayValue={getDisplayValue}
            />

            <AccountsInput
              value={data.totalAccountsPerAgent}
              onChange={handleInputChange}
              onNumberInputChange={handleNumberInputChange}
              getDisplayValue={getDisplayValue}
            />

            <ResolutionRateSlider
              value={data.currentResolutionRate}
              onChange={handleInputChange}
            />

            <DebtAmountInput
              debtValue={data.averageDebtPerAccount}
              currency={data.currency}
              onChange={handleInputChange}
              onNumberInputChange={handleNumberInputChange}
              getDisplayValue={getDisplayValue}
            />

            <CollectionCycleInput />
          </div>

          <CurrentPerformanceSection
            yearlyResolutions={results.yearlyResolutions}
            yearlyCollection={results.yearlyCollection}
            currency={data.currency}
          />
        </CardContent>
      </Card>
    </TooltipProvider>
  );
};

export default InputDataPane;
